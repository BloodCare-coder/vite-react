import React, { useState } from 'react';
import axios from 'axios';

export default function BookingForm() {
  const [user, setUser] = useState('');
  const [test, setTest] = useState('');
  const [date, setDate] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/bookings', { user, test, date });
      alert("Booking created successfully");
      setUser('');
      setTest('');
      setDate('');
    } catch (err) {
      alert("Failed to create booking");
    }
  };

  return (
    <div className="p-8 max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4">Book a Blood Test</h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <input type="text" placeholder="Your Name" value={user} onChange={(e) => setUser(e.target.value)} className="p-2 border rounded" required />
        <input type="text" placeholder="Test Name" value={test} onChange={(e) => setTest(e.target.value)} className="p-2 border rounded" required />
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="p-2 border rounded" required />
        <button type="submit" className="bg-blue-600 text-white py-2 rounded">Book Test</button>
      </form>
    </div>
  );
}
