const mongoose = require('mongoose');

const BookingSchema = new mongoose.Schema({
  user: String,
  test: String,
  date: Date,
  status: { type: String, default: "Pending" }
});

module.exports = mongoose.model("Booking", BookingSchema);
