const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');

router.post('/', async (req, res) => {
  const { user, test, date } = req.body;
  const newBooking = new Booking({ user, test, date });
  await newBooking.save();
  res.json({ message: 'Booking saved' });
});

router.get('/', async (req, res) => {
  const all = await Booking.find().sort({ date: -1 });
  res.json(all);
});

router.delete('/:id', async (req, res) => {
  await Booking.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
